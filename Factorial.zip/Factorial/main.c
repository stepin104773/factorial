#include "test_factorial.h"

int main(void)
{
	test_main();
	return 0;
}
